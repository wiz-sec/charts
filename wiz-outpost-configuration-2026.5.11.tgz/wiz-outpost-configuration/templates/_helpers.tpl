{{/*
Expand the name of the chart.
*/}}
{{- define "wiz-outpost-configuration.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "wiz-outpost-configuration.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "wiz-outpost-configuration.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "wiz-outpost-configuration.labels" -}}
helm.sh/chart: {{ include "wiz-outpost-configuration.chart" . }}
{{ include "wiz-outpost-configuration.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "wiz-outpost-configuration.selectorLabels" -}}
app.kubernetes.io/name: {{ include "wiz-outpost-configuration.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "wiz-outpost-configuration.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "wiz-outpost-configuration.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "wiz-network-analyzer.image" -}}
{{ .Values.networkAnalyzer.image.registry }}/{{ .Values.networkAnalyzer.image.repository }}:{{ .Values.networkAnalyzer.image.tag | default .Chart.AppVersion }}
{{- end -}}

{{/*
Resolve the flux namespace. Precedence:
  1. .Values.wizFluxNamespace                   (canonical, set by provisioner)
  2. .Values.outpostController.wizFluxNamespace (DEPRECATED, backward-compat)
  3. auto-derived from .Release.Namespace prefix
     (wiz-default -> wiz-flux-system, default -> flux-system).
*/}}
{{- define "wiz-outpost-configuration.fluxNamespace" -}}
{{- $nsPrefix := (index (splitList "-" .Release.Namespace) 0) -}}
{{- $autoFluxNamespace := ternary "flux-system" (printf "%s-flux-system" $nsPrefix) (eq .Release.Namespace "default") -}}
{{- $deprecated := default $autoFluxNamespace .Values.outpostController.wizFluxNamespace -}}
{{- default $deprecated .Values.wizFluxNamespace -}}
{{- end -}}

{{/*
Data block for the wiz-http-proxy-configuration Secret. Shared by the in-namespace
secret and the flux-namespace copy so both expose the same set of keys.
*/}}
{{- define "wiz-outpost-configuration.httpProxyConfiguration.data" -}}
{{- $noProxyCommaSeparatedList := join "," .Values.httpProxyConfiguration.noProxy -}}
{{- $noProxySpaceSeparatedList := join " " .Values.httpProxyConfiguration.noProxy -}}
httpProxy: {{ .Values.httpProxyConfiguration.httpProxy | default "" | b64enc | quote }}
http-proxy: {{ .Values.httpProxyConfiguration.httpProxy | default "" | b64enc | quote }}
httpsProxy: {{ .Values.httpProxyConfiguration.httpsProxy | default "" | b64enc | quote }}
https-proxy: {{ .Values.httpProxyConfiguration.httpsProxy | default "" | b64enc | quote }}
no-proxy-address: {{ $noProxySpaceSeparatedList | default "" | b64enc | quote }}
no-proxy-address-cs: {{ $noProxyCommaSeparatedList | default "" | b64enc | quote }}
noProxyAddress: {{ $noProxyCommaSeparatedList | default "" | b64enc | quote }}
noProxyAddressSpaceSepareted: {{ $noProxySpaceSeparatedList | default "" | b64enc | quote }}
caCertificate: {{ .Values.httpProxyConfiguration.caCertificate | default "" | b64enc | quote }}
clientCertificate: {{ .Values.httpProxyConfiguration.clientCertificate | default "" | b64enc | quote }}
{{- end -}}
