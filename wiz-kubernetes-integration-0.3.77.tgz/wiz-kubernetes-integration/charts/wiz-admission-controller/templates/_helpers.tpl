{{/*
Expand the name of the chart.
*/}}
{{- define "wiz-admission-controller.name" -}}
{{- $nameOverride := coalesce .Values.global.nameOverride .Values.nameOverride }}
{{- default .Chart.Name $nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "wiz-admission-controller.fullname" -}}
{{- if .Values.global.fullnameOverride }}
{{- .Values.global.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := coalesce .Values.global.nameOverride .Values.nameOverride .Chart.Name }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "wiz-admission-controller-enforcer.name" -}}
{{- (include "wiz-admission-controller.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Append a fixed suffix to a base name, truncating the base (never the suffix) so the
result stays within max chars (default 63 — the Kubernetes DNS name limit).
Args: dict "base" <name> "suffix" "-..." [ "max" 63 ]
*/}}
{{- define "wiz-admission-controller.truncatedNameWithSuffix" -}}
{{- $max := .max | default 63 -}}
{{- printf "%s%s" (.base | trunc (int (sub $max (len .suffix))) | trimSuffix "-") .suffix -}}
{{- end -}}

{{- define "wiz-kubernetes-audit-log-collector.name" -}}
{{- if .Values.kubernetesAuditLogsWebhook.nameOverride }}
{{- .Values.kubernetesAuditLogsWebhook.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- include "wiz-admission-controller.truncatedNameWithSuffix" (dict "base" (include "wiz-admission-controller.fullname" .) "suffix" "-audit-log-collector") -}}
{{- end }}
{{- end }}

{{- define "wiz-sensor-inject.name" -}}
{{- if .Values.sensorInject.nameOverride }}
{{- .Values.sensorInject.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- include "wiz-admission-controller.truncatedNameWithSuffix" (dict "base" (include "wiz-admission-controller.fullname" .) "suffix" "-sensor-inject") -}}
{{- end }}
{{- end }}

{{- define "wiz-debug-webhook.name" -}}
{{- if .Values.debugWebhook.nameOverride }}
{{- .Values.debugWebhook.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- include "wiz-admission-controller.truncatedNameWithSuffix" (dict "base" (include "wiz-admission-controller.fullname" .) "suffix" "-debug") -}}
{{- end }}
{{- end }}

{{- define "wiz-admission-controller-manager.name" -}}
{{- if .Values.wizManager.nameOverride }}
{{- .Values.wizManager.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- include "wiz-admission-controller.truncatedNameWithSuffix" (dict "base" (include "wiz-admission-controller.fullname" .) "suffix" "-manager" "max" 52) -}}
{{- end }}
{{- end }}

{{- define "wiz-admission-controller-uninstall.name" -}}
{{- if .Values.wizUninstallJob.nameOverride }}
{{- .Values.wizUninstallJob.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- include "wiz-admission-controller.truncatedNameWithSuffix" (dict "base" (include "wiz-admission-controller.fullname" .) "suffix" "-uninstall") -}}
{{- end }}
{{- end }}

{{- define "wiz-admission-controller.wiz-hpa-enforcer.name" -}}
{{- include "wiz-admission-controller.truncatedNameWithSuffix" (dict "base" (include "wiz-admission-controller.fullname" .) "suffix" "-hpa") -}}
{{- end }}

{{- define "wiz-admission-controller.wiz-hpa-audit-logs.name" -}}
{{- include "wiz-admission-controller.truncatedNameWithSuffix" (dict "base" (include "wiz-kubernetes-audit-log-collector.name" .) "suffix" "-hpa") -}}
{{- end }}

{{- define "wiz-admission-controller.wiz-hpa-debug.name" -}}
{{- include "wiz-admission-controller.truncatedNameWithSuffix" (dict "base" (include "wiz-debug-webhook.name" .) "suffix" "-hpa") -}}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "wiz-admission-controller.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
App version for the admission controller
*/}}
{{- define "wiz-admission-controller.appVersion" -}}
{{- coalesce .Values.global.image.tag .Values.image.tag | default .Chart.AppVersion }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "wiz-admission-controller.labels" -}}
helm.sh/chart: {{ include "wiz-admission-controller.chart" . }}
{{ include "wiz-admission-controller.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ include "wiz-admission-controller.appVersion" . | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- if .Values.commonLabels }}
{{- range $index, $content := .Values.commonLabels }}
{{ $index }}: {{ tpl $content $ | quote }}
{{- end }}
{{- end }}
{{- if .Values.global.commonLabels }}
{{- range $index, $content := .Values.global.commonLabels }}
{{ $index }}: {{ tpl $content $ | quote }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Wiz admission controller webhook server selector labels
*/}}
{{- define "wiz-admission-controller.selectorLabels" -}}
app.kubernetes.io/chartName: {{ .Chart.Name | trunc 63 }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Wiz admission controller enforcement webhook server selector labels
*/}}
{{- define "wiz-admission-controller-enforcement.selectorLabels" -}}
app.kubernetes.io/name: {{ include "wiz-admission-controller.name" . }}
{{- end }}

{{/*
Wiz kubernetes audit logs webhook server selector labels
*/}}
{{- define "wiz-kubernetes-audit-log-collector.selectorLabels" -}}
app.kubernetes.io/name: {{ include "wiz-kubernetes-audit-log-collector.name" . }}
{{- end }}

{{/*
Wiz sensor webhook server selector labels
*/}}
{{- define "wiz-sensor-webhook.selectorLabels" -}}
app.kubernetes.io/name: {{ include "wiz-sensor-inject.name" . }}
{{- end }}

{{/*
Wiz debug webhook server selector labels
*/}}
{{- define "wiz-debug-webhook.selectorLabels" -}}
app.kubernetes.io/name: {{ include "wiz-debug-webhook.name" . }}
{{- end }}

{{/*
Wiz manager selector labels
*/}}
{{- define "wiz-admission-controller-manager.selectorLabels" -}}
app.kubernetes.io/name: {{ include "wiz-admission-controller-manager.name" . }}
{{- end }}

{{/*
Wiz uninstall selector labels
*/}}
{{- define "wiz-admission-controller-uninstall.selectorLabels" -}}
app.kubernetes.io/name: {{ include "wiz-admission-controller-uninstall.name" . }}
{{- end }}


{{- define "wiz-admission-controller-enforcement.labels" -}}
{{ include "wiz-admission-controller.labels" . }}
{{ include "wiz-admission-controller-enforcement.selectorLabels" . }}
{{- end }}

{{- define "wiz-kubernetes-audit-log-collector.labels" -}}
{{ include "wiz-admission-controller.labels" . }}
{{ include "wiz-kubernetes-audit-log-collector.selectorLabels" . }}
{{- end }}

{{- define "wiz-sensor-webhook.labels" -}}
{{ include "wiz-admission-controller.labels" . }}
{{ include "wiz-sensor-webhook.selectorLabels" . }}
{{- end }}

{{- define "wiz-debug-webhook.labels" -}}
{{ include "wiz-admission-controller.labels" . }}
{{ include "wiz-debug-webhook.selectorLabels" . }}
{{- end }}

{{- define "wiz-admission-controller-manager.labels" -}}
{{ include "wiz-admission-controller.labels" . }}
{{ include "wiz-admission-controller-manager.selectorLabels" . }}
{{- end }}

{{- define "wiz-admission-controller-uninstall.labels" -}}
{{ include "wiz-admission-controller.labels" . }}
{{ include "wiz-admission-controller-uninstall.selectorLabels" . }}
{{- end }}

{{/*
Wiz Horizontal Pod Autoscaler labels
*/}}

{{- define "wiz-admission-controller.wiz-admission-controller.wiz-hpa-enforcer.labels" -}}
{{ include "wiz-admission-controller.labels" . }}
app.kubernetes.io/name: {{ include "wiz-admission-controller.wiz-hpa-enforcer.name" . }}
{{- end }}

{{- define "wiz-admission-controller.wiz-hpa-audit-logs.labels" -}}
{{ include "wiz-admission-controller.labels" . }}
app.kubernetes.io/name: {{ include "wiz-admission-controller.wiz-hpa-audit-logs.name" . }}
{{- end }}

{{- define "wiz-admission-controller.wiz-hpa-debug.labels" -}}
{{ include "wiz-admission-controller.labels" . }}
app.kubernetes.io/name: {{ include "wiz-admission-controller.wiz-hpa-debug.name" . }}
{{- end }}


{{/*
Create the name of the service account to use
*/}}
{{- define "wiz-admission-controller.serviceAccountName" -}}
{{ coalesce (.Values.serviceAccount.name) (include "wiz-admission-controller.fullname" .) }}
{{- end }}

{{- define "wiz-admission-controller.manager.serviceAccountName" -}}
{{ coalesce (.Values.wizManager.serviceAccount.name) (include "wiz-admission-controller-manager.name" .) }}
{{- end }}


{{- define "wiz-admission-controller.secretApiTokenName" -}}
{{ coalesce (.Values.global.wizApiToken.secret.name) (.Values.wizApiToken.secret.name) (printf "%s-%s" .Release.Name "api-token") }}
{{- end }}

{{/*
Leader-lease and CRD-cache resources are named off the chart fullname so multiple
releases on the same cluster don't share a lease/cache. The runner type lives in
the suffix so it always survives truncation.
*/}}
{{- define "wiz-admission-controller.globalLeaderLeaseName" -}}
{{- include "wiz-admission-controller.truncatedNameWithSuffix" (dict "base" (include "wiz-admission-controller.fullname" .) "suffix" "-global-lease") -}}
{{- end }}

{{- define "wiz-admission-controller.secretServerCert" -}}
{{- if .Values.webhook.secret.name }}
{{- .Values.webhook.secret.name }}
{{- else }}
{{- include "wiz-admission-controller.fullname" . }}-cert
{{- end }}
{{- end }}

{{- define "wiz-admission-controller.opaEnvVars.policies" -}}
{{- if .Values.opaWebhook.policies }}
- name: WIZ_POLICY
  value: {{ .Values.opaWebhook.policies | join "," | quote }}
{{- end }}
{{- end }}

{{- define "wiz-admission-controller.imageIntegrityEnvVars.policies" -}}
{{- if .Values.imageIntegrityWebhook.policies }}
- name: WIZ_IMAGE_INTEGRITY_POLICY
  value: {{ .Values.imageIntegrityWebhook.policies | join "," | quote }}
{{- end }}
{{- end }}

{{- define "wiz-admission-controller.sensorApiKeySecretName" -}}
  {{- $secretName := coalesce .Values.sensorInject.apiKeySecret.name .Values.global.wizApiToken.secret.name .Values.wizApiToken.secret.name -}}
  {{- if not (empty $secretName) -}}
    {{- $secretName -}}
  {{- end -}}
{{- end -}}

{{- define "wiz-admission-controller.sensorCliParams" -}}
{{- if .Values.sensorInject.enabled }}
- "--sensor-api-key-secret-name={{ required "one of sensorInject.apiKeySecret.name or wizApiToken.secret.name or global.wizApiToken.secret.name is required when sensorInject.enabled is true" ( include "wiz-admission-controller.sensorApiKeySecretName" .) }}"
- "--sensor-registry-secret-name={{ required "sensorInject.registrySecret.name is required when sensorInject.enabled is true" .Values.sensorInject.registrySecret.name }}"
{{- if .Values.sensorInject.image }}
- "--sensor-image={{ .Values.sensorInject.image }}"
{{- end }}
{{- if .Values.sensorInject.excludedContainers }}
{{- range .Values.sensorInject.excludedContainers }}
- "--sensor-excluded-containers={{ . }}"
{{- end }}
{{- end }}
{{- if .Values.sensorInject.stdoutLogLevel }}
- "--sensor-stdout-log-level={{ .Values.sensorInject.stdoutLogLevel }}"
{{- end }}
{{- end }}
{{- end }}

{{- define "wiz-admission-controller.imageRegistryClient.pullSecrets" -}}
{{- if .Values.imageRegistryClient.pullSecrets }}
{{- range .Values.imageRegistryClient.pullSecrets }}
- "--registry-image-pull-secret={{ . }}"
{{- end }}
{{- end }}
{{- end }}

{{- define "wiz-admission-controller.imageRegistryClient.credentialHelpersSecrets" -}}
{{- if .Values.imageRegistryClient.credentialHelpers }}
{{- range .Values.imageRegistryClient.credentialHelpers }}
- "--registry-credential-helper={{ . }}"
{{- end }}
{{- end }}
{{- end }}


{{- define "wiz-admission-controller.proxySecretName" -}}
{{ coalesce (.Values.global.httpProxyConfiguration.secretName) (.Values.httpProxyConfiguration.secretName) (printf "%s-%s" .Release.Name "proxy-configuration") }}
{{- end }}

{{- define "wiz-admission-controller.proxyHash" -}}
{{ include "helpers.calculateHash" (list .Values.global.httpProxyConfiguration.httpProxy .Values.global.httpProxyConfiguration.httpsProxy .Values.global.httpProxyConfiguration.noProxyAddress .Values.global.httpProxyConfiguration.secretName .Values.httpProxyConfiguration.httpProxy .Values.httpProxyConfiguration.httpsProxy .Values.httpProxyConfiguration.noProxyAddress .Values.httpProxyConfiguration.secretName) }}
{{- end }}

{{- define "wiz-admission-controller.wizApiTokenHash" -}}
{{ include "helpers.calculateHash" (list .Values.global.wizApiToken.clientId .Values.global.wizApiToken.clientToken .Values.global.wizApiToken.secret.name .Values.wizApiToken.clientId .Values.wizApiToken.clientToken .Values.wizApiToken.secret.name) }}
{{- end }}

{{- define "wiz-admission-controller.certManagerInject" -}}
{{- if .Values.webhook.createSelfSignedCert -}}
{{- printf "%s/%s-cert" .Release.Namespace (include "wiz-admission-controller.fullname" .) -}}
{{- else -}}
{{- .Values.webhook.injectCaFrom -}}
{{- end -}}
{{- end -}}

{{- define "wiz-admission-controller.resources" -}}
{{- if hasKey .Values "resources" }}
{{- toYaml .Values.resources }}
{{- else -}}
{{- if .Values.hpa.enabled }}
requests:
    cpu: 500m
    memory: 300Mi
{{- else }}
{}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "wiz-admission-controller.isEnforcerEnabled" -}}
  {{- if or .Values.opaWebhook.enabled .Values.imageIntegrityWebhook.enabled }}
    true
  {{- else }}
    false
  {{- end }}
{{- end }}

{{- define "wiz-admission-controller.hpaBehavior" -}}
{{- if hasKey .Values.hpa "behavior" }}
{{- toYaml .Values.hpa.behavior }}
{{- else -}}
scaleUp:
  stabilizationWindowSeconds: 300
scaleDown:
  stabilizationWindowSeconds: 300
  policies:
  - type: Pods
    value: 1
    periodSeconds: 300
{{- end -}}
{{- end -}}

{{- define "wiz-admission-controller.autoUpdate.deployments" -}}
{{- $list := list -}}
{{- if eq (include "wiz-admission-controller.isEnforcerEnabled" . | trim | lower) "true" }}
{{- $list = append $list (include "wiz-admission-controller-enforcer.name" . ) -}}
{{- end -}}
{{- if .Values.kubernetesAuditLogsWebhook.enabled -}}
{{- $list = append $list (include "wiz-kubernetes-audit-log-collector.name" . ) -}}
{{- end -}}
{{- if .Values.sensorInject.enabled -}}
{{- $list = append $list (include "wiz-sensor-inject.name" . ) -}}
{{- end -}}
{{- if .Values.debugWebhook.enabled -}}
{{- $list = append $list (include "wiz-debug-webhook.name" . ) -}}
{{- end -}}
{{- $list | toJson -}}
{{- end -}}

{{/*
Clean the list of deployments for the auto-update flag, removing quotes and brackets
*/}}
{{- define "wiz-admission-controller.wiz-admission-controller.autoUpdate.deployments.arg" -}}
{{- $deployments := include "wiz-admission-controller.autoUpdate.deployments" .  -}}
{{- $deployments = replace "[" "" $deployments -}}
{{- $deployments = replace "]" "" $deployments -}}
{{- $deployments = replace "\"" "" $deployments -}}
- "--update-deployments={{ $deployments }}"
{{- end -}}

{{- define "wiz-admission-controller.spec.common.commandArgs" -}}
# Cluster identification flags
{{- with (coalesce .Values.global.clusterExternalId .Values.webhook.clusterExternalId .Values.opaWebhook.clusterExternalId) }}
- --cluster-external-id
- {{ . | quote }}
{{- end }}
{{- with (coalesce .Values.global.subscriptionExternalId .Values.webhook.subscriptionExternalId) }}
- --subscription-external-id
- {{ . | quote }}
{{- end }}
{{- with (coalesce .Values.global.clusterTags .Values.webhook.clusterTags) }}
- --cluster-tags
- {{ . | toJson | quote }}
{{- end }}
{{- with (coalesce .Values.global.subscriptionTags .Values.webhook.subscriptionTags) }}
- --subscription-tags
- {{ . | toJson | quote }}
{{- end }}
{{- end -}}

{{- define "spec.admissionControllerRunner.commandArgs" -}}
# Server flags
- "--port={{ .Values.service.targetPort }}"
- "--tls-private-key-file=/var/server-certs/tls.key"
- "--tls-cert-file=/var/server-certs/tls.crt"
- "--readiness-port={{ .Values.healthPort }}"
# Kubernetes API server flags
- "--namespace-cache-ttl={{ .Values.kubernetesApiServer.cacheNamespaceLabelsTTL }}"
{{- end -}}

{{- define "wiz-admission-controller.isWizApiTokenSecretEnabled" -}}
  {{- if and (.Values.wizApiToken.secret.create) (eq (include "wiz-common.isWizApiClientVolumeMountEnabled" (list .Values.wizApiToken.usePodCustomEnvironmentVariablesFile .Values.wizApiToken.wizApiTokensVolumeMount .Values.global.wizApiToken.wizApiTokensVolumeMount) | trim | lower) "true") }}
    true
  {{- else }}
    false
  {{- end }}
{{- end }}

{{- define "wiz-admission-controller.isWizApiClientVolumeMountEnabled" -}}
{{- if eq (include "wiz-common.isWizApiClientVolumeMountEnabled" (list .Values.wizApiToken.usePodCustomEnvironmentVariablesFile .Values.wizApiToken.wizApiTokensVolumeMount .Values.global.wizApiToken.wizApiTokensVolumeMount) | trim | lower) "true" -}}
true
{{- else -}}
false
{{- end }}
{{- end }}


{{- define "wiz-admission-controller.spec.common.volumeMounts" -}}
{{- if eq (include "wiz-admission-controller.isWizApiClientVolumeMountEnabled" . | trim | lower) "true" }}
- name: {{ include "wiz-common.volumes.apiClientName" . }}
  mountPath: /var/{{ include "wiz-common.volumes.apiClientName" . }}
  readOnly: true
{{- end -}}
{{- if or .Values.global.httpProxyConfiguration.enabled .Values.httpProxyConfiguration.enabled }}
{{ include "wiz-common.proxy.volumeMount" . | trim }}
{{- end -}}
{{- end -}}

{{- define "wiz-admission-controller.spec.common.volumes" -}}
{{- if eq (include "wiz-admission-controller.isWizApiClientVolumeMountEnabled" . | trim | lower) "true" }}
- name: {{ include "wiz-common.volumes.apiClientName" . | trim }}
  secret:
    secretName: {{ include "wiz-admission-controller.secretApiTokenName" . | trim }}
{{- end }}
{{- if or .Values.global.httpProxyConfiguration.enabled .Values.httpProxyConfiguration.enabled }}
{{ include "wiz-common.proxy.volume" (list (include "wiz-admission-controller.proxySecretName" . | trim )) | trim }}
{{- end -}}
{{- end -}}


{{- define "wiz-admission-controller.fsQueue.dir" -}}
/var/run/wiz/queue
{{- end -}}

{{- /* Converts a Kubernetes memory quantity (e.g. 150Mi, 1Gi, 500M) to bytes.
       Suffix matching is case-sensitive to mirror Kubernetes quantity parsing, so
       values that would be rejected at apply time also fail our validation. */ -}}
{{- define "wiz-admission-controller.memoryToBytes" -}}
  {{- $q := . | toString -}}
  {{- $bytes := 0.0 -}}
  {{- if hasSuffix "Ki" $q -}}
    {{- $bytes = mulf (trimSuffix "Ki" $q | float64) 1024.0 -}}
  {{- else if hasSuffix "Mi" $q -}}
    {{- $bytes = mulf (trimSuffix "Mi" $q | float64) 1048576.0 -}}
  {{- else if hasSuffix "Gi" $q -}}
    {{- $bytes = mulf (trimSuffix "Gi" $q | float64) 1073741824.0 -}}
  {{- else if hasSuffix "Ti" $q -}}
    {{- $bytes = mulf (trimSuffix "Ti" $q | float64) 1099511627776.0 -}}
  {{- else if hasSuffix "Pi" $q -}}
    {{- $bytes = mulf (trimSuffix "Pi" $q | float64) 1125899906842624.0 -}}
  {{- else if hasSuffix "k" $q -}}
    {{- $bytes = mulf (trimSuffix "k" $q | float64) 1000.0 -}}
  {{- else if hasSuffix "M" $q -}}
    {{- $bytes = mulf (trimSuffix "M" $q | float64) 1000000.0 -}}
  {{- else if hasSuffix "G" $q -}}
    {{- $bytes = mulf (trimSuffix "G" $q | float64) 1000000000.0 -}}
  {{- else if hasSuffix "T" $q -}}
    {{- $bytes = mulf (trimSuffix "T" $q | float64) 1000000000000.0 -}}
  {{- else if hasSuffix "P" $q -}}
    {{- $bytes = mulf (trimSuffix "P" $q | float64) 1000000000000000.0 -}}
  {{- else -}}
    {{- $bytes = $q | float64 -}}
  {{- end -}}
  {{- printf "%.0f" $bytes -}}
{{- end -}}

{{- define "wiz-admission-controller.spec.common.runner.volumeMounts" -}}
{{- include "wiz-admission-controller.spec.common.volumeMounts" . }}
{{- if .Values.fsQueue.enabled }}
- mountPath: {{ include "wiz-admission-controller.fsQueue.dir" . }}
  name: fs-queue
{{- end -}}
{{- end -}}

{{- define "wiz-admission-controller.spec.common.runner.volumes" -}}
{{- include "wiz-admission-controller.spec.common.volumes" . }}
{{- if .Values.fsQueue.enabled }}
- name: fs-queue
  emptyDir:
    medium: Memory
    sizeLimit: {{ .Values.fsQueue.sizeLimit }}
{{- end -}}
{{- end -}}

{{- define "wiz-admission-controller.spec.common.envVars" -}}
{{- if not .Values.wizApiToken.usePodCustomEnvironmentVariablesFile }}
- name: CLI_FILES_AS_ARGS
{{- $wizApiTokensPath := "" -}}
{{- if coalesce .Values.wizApiToken.wizApiTokensVolumeMount .Values.global.wizApiToken.wizApiTokensVolumeMount }}
  {{- $wizApiTokensPath = coalesce .Values.wizApiToken.wizApiTokensVolumeMount .Values.global.wizApiToken.wizApiTokensVolumeMount -}}
{{- else }}
  {{- $wizApiTokensPath = printf "/var/%s" (include "wiz-common.volumes.apiClientName" .) -}}
{{- end }}
  value: "{{ $wizApiTokensPath }}/clientToken,{{ $wizApiTokensPath }}/clientId"
{{- end }}
{{- if or .Values.global.httpProxyConfiguration.enabled .Values.httpProxyConfiguration.enabled }}
{{ include "wiz-common.proxy.env" . | trim }}
{{- if or .Values.global.httpProxyConfiguration.clientCertificate .Values.httpProxyConfiguration.clientCertificate }}
- name: WIZ_HTTP_PROXY_CLIENT_CERT_PATH
  value: "{{ include "wiz-common.proxy.dir" . }}/clientCertificate"
{{- end }}
{{- end }}
- name: WIZ_ENV
  value: {{ coalesce .Values.global.wizApiToken.clientEndpoint .Values.wizApiToken.clientEndpoint | quote }}
{{- if .Values.fsQueue.enabled }}
- name: WIZ_FS_DIR
  value: {{ include "wiz-admission-controller.fsQueue.dir" . | quote }}
- name: WIZ_FS_VOLUME_SIZE
  value: {{ .Values.fsQueue.sizeLimit | quote }}
{{- end }}
{{- if .Values.global.awsPrivateLink.enabled }}
- name: USE_WIZ_PRIVATE_LINK_ENDPOINTS
  value: "true"
{{- end }}
{{- if .Values.logLevel }}
- name: LOG_LEVEL
  value: {{ .Values.logLevel }}
{{- end }}
{{- with .Values.podCustomEnvironmentVariables }}
{{ toYaml . }}
{{- end }}
{{- with .Values.global.podCustomEnvironmentVariables }}
{{ toYaml . }}
{{- end }}
{{- if .Values.podCustomEnvironmentVariablesFile }}
- name: CLI_ENV_FILE
  value: {{ .Values.podCustomEnvironmentVariablesFile }}
- name: USE_CLI_ENV_FILE
  value: "true"
{{- end }}
- name: WIZ_RUNTIME_METADATA_POD_NAME
  valueFrom:
    fieldRef:
      fieldPath: metadata.name
- name: WIZ_RUNTIME_METADATA_NODE_NAME
  valueFrom:
    fieldRef:
      fieldPath: spec.nodeName
- name: K8S_NAMESPACE
  valueFrom:
    fieldRef:
      fieldPath: metadata.namespace
- name: WIZ_TERMINATION_GRACE_PERIOD
  value: "{{ .Values.global.podTerminationGracePeriodSeconds }}s"
{{- if .Values.crdCache.enabled }}
- name: WIZ_CRD_CACHE_ENABLED
  value: "true"
- name: WIZ_CRD_CACHE_MAX_AGE
  value: "{{ .Values.crdCache.maxAge }}"
{{- end }}
{{- if .Values.global.istio.enabled }}
- name: WIZ_ISTIO_PROXY_ENABLED
  value: "true"
- name: WIZ_ISTIO_PROXY_PORT
  value: "{{ .Values.global.istio.proxySidecarPort }}"
{{- end }}
- name: WIZ_CHART_VERSION
  value: "{{ .Chart.Version}}"
{{- if .Values.memmonitor.enabled }}
- name: WIZ_MEMMONITOR_ENABLED
  value: {{ .Values.memmonitor.enabled | quote }}
- name: WIZ_MEMMONITOR_UPLOAD_ENABLED
  value: {{ .Values.memmonitor.uploadEnabled | quote }}
- name: WIZ_MEMMONITOR_MEMORY_LIMIT_RATIO
  value: {{ .Values.memmonitor.memoryLimitRatio | quote }}
{{- end }}
{{- if (or .Values.imageIntegrityWebhook.customErrorMessage .Values.customErrorMessage) }}
- name: WIZ_IMAGE_INTEGRITY_CUSTOM_ERROR_MESSAGE
  value:  "{{ coalesce .Values.imageIntegrityWebhook.customErrorMessage .Values.customErrorMessage }}"
{{- if (or .Values.imageIntegrityWebhook.customErrorMessageMode .Values.customErrorMessageMode) }}
- name: WIZ_IMAGE_INTEGRITY_CUSTOM_ERROR_MESSAGE_MODE
  value:  "{{ coalesce .Values.imageIntegrityWebhook.customErrorMessageMode .Values.customErrorMessageMode }}"
{{- end -}}
{{- end -}}
{{- if (or .Values.opaWebhook.customErrorMessage .Values.customErrorMessage) }}
- name: WIZ_MISCONFIGURATION_CUSTOM_ERROR_MESSAGE
  value:  "{{ coalesce .Values.opaWebhook.customErrorMessage .Values.customErrorMessage }}"
{{- if (or .Values.opaWebhook.customErrorMessageMode .Values.customErrorMessageMode) }}
- name: WIZ_MISCONFIGURATION_CUSTOM_ERROR_MESSAGE_MODE
  value:  "{{ coalesce .Values.opaWebhook.customErrorMessageMode .Values.customErrorMessageMode }}"
{{- end -}}
{{- end -}}
{{- if coalesce .Values.global.clusterDisplayName .Values.clusterDisplayName }}
- name: WIZ_CLUSTER_NAME
  value: {{ coalesce .Values.global.clusterDisplayName .Values.clusterDisplayName | quote }}
{{- end }}
{{- if .Values.prometheus.enabled }}
# Prometheus metrics configuration
- name: WIZ_METRICS_ENABLED
  value: {{ .Values.prometheus.enabled | quote }}
- name: WIZ_METRICS_PORT
  value: {{ .Values.prometheus.metricsPort | quote }}
- name: WIZ_DISABLE_TLS_METRICS
  value: {{ .Values.prometheus.diableTLS | quote }}
{{- end }}
- name: WIZ_GLOBAL_LEADER_LEASE_NAME
  value: {{ include "wiz-admission-controller.globalLeaderLeaseName" . }}
- name: WIZ_SCRAPE_API_SERVER_METRICS_ENABLED
  value: {{ include "wiz-admission-controller.scrapeAPIServerMetricsEnabled" . | trim | quote }}
{{- if and .Values.wizManager.enabled .Values.wizManager.selfLoop.enabled }}
- name: WIZ_SELFLOOP_ENABLED
  value: "true"
- name: WIZ_SELFLOOP_PROBE_LABEL
  value: {{ .Values.wizManager.selfLoop.probeLabel | quote }}
{{- end }}
{{- end -}}

{{- define "wiz-admission-controller.image" -}}
{{ coalesce .Values.global.image.registry .Values.image.registry }}/{{ coalesce .Values.global.image.repository .Values.image.repository }}:{{ include "wiz-admission-controller.appVersion" . }}
{{- end -}}

{{/*
Common service ports configuration
*/}}
{{- define "wiz-admission-controller.service.ports" -}}
- port: {{ .Values.service.port }}
  targetPort: {{ .Values.service.targetPort }}
  protocol: TCP
  name: webhook
{{- if .Values.prometheus.enabled }}
- port: {{ .Values.prometheus.metricsPort }}
  targetPort: metrics
  protocol: TCP
  name: metrics
{{- end }}
{{- end -}}

{{/*
Get Kubernetes version, with support for mocking in tests
*/}}
{{- define "wiz-admission-controller.kubeVersion" -}}
{{- if and .Values.mockCapabilities .Values.mockCapabilities.kubeVersion .Values.mockCapabilities.kubeVersion.version -}}
{{ .Values.mockCapabilities.kubeVersion.version }}
{{- else -}}
{{ .Capabilities.KubeVersion.Version }}
{{- end -}}
{{- end -}}

{{/*
Lookup existing TLS secret, with support for mocking in tests
*/}}
{{- define "wiz-admission-controller.lookupTlsSecret" -}}
{{- if .Values.mockLookup -}}
{{- .Values.mockLookup.tlsSecret | default dict | toJson -}}
{{- else -}}
{{- $secretName := include "wiz-admission-controller.secretServerCert" . | trim -}}
{{- lookup "v1" "Secret" .Release.Namespace $secretName | default dict | toJson -}}
{{- end -}}
{{- end -}}

{{/*
Determine if scraping API server metrics is enabled, considering K8s version >= 1.21 (GA API for EndpointSlices)
*/}}
{{- define "wiz-admission-controller.scrapeAPIServerMetricsEnabled" -}}
{{- if and .Values.scrapeAPIServerMetrics.enabled (semverCompare ">=1.21-0" (include "wiz-admission-controller.kubeVersion" .)) -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}


{{/*
Common container ports configuration
*/}}
{{- define "wiz-admission-controller.container.ports" -}}
- containerPort: {{ .Values.service.targetPort }}
{{- if .Values.prometheus.enabled }}
- name: metrics
  containerPort: {{ .Values.prometheus.metricsPort }}
{{- end }}
{{- end -}}

{{/*
Runner type constants
*/}}
{{- define "wiz-admission-controller.runnerType.enforcer" -}}
enforcer
{{- end -}}

{{- define "wiz-admission-controller.runnerType.kdr" -}}
kdr
{{- end -}}

{{- define "wiz-admission-controller.runnerType.sensor" -}}
sensor
{{- end -}}

{{/*
Get list of all enabled runner types
Returns: list of runner types that are enabled
*/}}
{{- define "wiz-admission-controller.enabledRunnerTypes" -}}
{{- $types := list -}}
{{- if or .Values.opaWebhook.enabled .Values.imageIntegrityWebhook.enabled -}}
{{- $types = append $types (include "wiz-admission-controller.runnerType.enforcer" .) -}}
{{- end -}}
{{- if .Values.kubernetesAuditLogsWebhook.enabled -}}
{{- $types = append $types (include "wiz-admission-controller.runnerType.kdr" .) -}}
{{- end -}}
{{- if .Values.sensorInject.enabled -}}
{{- $types = append $types (include "wiz-admission-controller.runnerType.sensor" .) -}}
{{- end -}}
{{- $types | toJson -}}
{{- end -}}

{{/*
Get the leader lock ID for a specific runner type
Args: dict "root" $ "runnerType" "enforcer"
*/}}
{{- define "wiz-admission-controller.leaderLockId" -}}
{{- include "wiz-admission-controller.truncatedNameWithSuffix" (dict "base" (include "wiz-admission-controller.fullname" .root) "suffix" (printf "-crd-cache-%s" .runnerType)) -}}
{{- end -}}

{{/*
Get the cache name prefix for a specific runner type
Args: dict "root" $ "runnerType" "enforcer"
*/}}
{{- define "wiz-admission-controller.cacheNamePrefix" -}}
{{- include "wiz-admission-controller.truncatedNameWithSuffix" (dict "base" (include "wiz-admission-controller.fullname" .root) "suffix" (printf "-cache-%s" .runnerType)) -}}
{{- end -}}

{{/*
Generate CRD cache environment variables for a specific runner type
Usage: include "wiz-admission-controller.crdCacheEnvVars" (dict "root" $ "runnerType" "enforcer")
*/}}
{{- define "wiz-admission-controller.crdCacheEnvVars" -}}
- name: WIZ_CRD_CACHE_LEADER_LOCK_ID
  value: {{ include "wiz-admission-controller.leaderLockId" . }}
- name: WIZ_CRD_CACHE_NAME_PREFIX
  value: {{ include "wiz-admission-controller.cacheNamePrefix" . }}
{{- end -}}

{{/*
Renders a webhook entry from a config dict.
Params:
  root              - root context (.)
  webhookName       - e.g. "misconfigurationsadmissionvalidator"
  serviceName       - K8s service name
  path              - webhook path, e.g. "/opa-validator"
  tlsCrt            - base64-encoded CA cert
  useCertManagerCerts - bool, skip caBundle if true
  rules             - list of RuleWithOperations
  additionalRules   - optional extra rules to append
  namespaceSelector - namespace selector dict
  objectSelector    - optional object selector dict
  timeoutSeconds    - webhook timeout
  sideEffects       - e.g. "None"
*/}}
{{- define "wiz-admission-controller.webhookEntry" -}}
- name: {{ .webhookName }}
  admissionReviewVersions: ["v1", "v1beta1"]
  clientConfig:
    service:
      namespace: {{ .root.Release.Namespace }}
      name: {{ .serviceName }}
      path: {{ .path }}
      port: {{ .root.Values.service.port }}
{{- if not .useCertManagerCerts }}
    caBundle: {{ .tlsCrt }}
{{- end }}
  {{- with .rules }}
  rules:
    {{- toYaml . | nindent 4 }}
    {{- with $.additionalRules }}
    {{- toYaml . | nindent 4 }}
    {{- end }}
  {{- end }}
  {{- with .namespaceSelector }}
  namespaceSelector:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- with .objectSelector }}
  objectSelector:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- with .matchConditions }}
  matchConditions:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  timeoutSeconds: {{ .timeoutSeconds }}
  failurePolicy: {{ .failurePolicy | default "Ignore" }}
  sideEffects: {{ .sideEffects }}
{{- end -}}

{{/*
Fixed rules for the sensor webhook — only watches pod creates.
*/}}
{{- define "wiz-admission-controller.sensor.rules" -}}
- operations: ["CREATE"]
  apiGroups: ["*"]
  apiVersions: ["*"]
  resources: ["pods"]
{{- end -}}

{{/*
Fixed rules for self-loop webhook entries — only watches deployment updates.
*/}}
{{- define "wiz-admission-controller.selfLoop.rules" -}}
- operations: ["UPDATE"]
  apiGroups: ["apps"]
  apiVersions: ["v1"]
  resources: ["deployments"]
{{- end -}}

{{/*
Self-loop webhook names — the unique identifier for each self-loop entry.
Used in: webhook entry name, objectSelector label value, and manager env vars.
*/}}
{{- define "wiz-admission-controller.selfLoop.name.misconfiguration" -}}selfloop.misconfigurationsadmissionvalidator.wiz.io{{- end -}}
{{- define "wiz-admission-controller.selfLoop.name.imageIntegrity" -}}selfloop.imageintegrityadmissionvalidator.wiz.io{{- end -}}
{{- define "wiz-admission-controller.selfLoop.name.kdr" -}}selfloop.kubernetesauditlogs.wiz.io{{- end -}}

{{/*
objectSelector for self-loop webhook entries.
Params (passed as a list): [root, selfLoopName]
*/}}
{{- define "wiz-admission-controller.selfLoop.objectSelector" -}}
{{- $root := index . 0 -}}
{{- $selfLoopName := index . 1 -}}
matchLabels:
  {{ $root.Values.wizManager.selfLoop.probeLabel }}: {{ $selfLoopName | quote }}
{{- end -}}

{{/*
namespaceSelector for self-loop webhook entries — locked to release namespace.
*/}}
{{- define "wiz-admission-controller.selfLoop.namespaceSelector" -}}
matchExpressions:
- key: kubernetes.io/metadata.name
  operator: In
  values:
  - {{ .Release.Namespace }}
{{- end -}}

